#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Home
#
# Created:     25.04.2014
# Copyright:   (c) Home 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------
money = 10
bread = 0

if money == 20:
    print("Need to buy the bread!")
elif money == 10:
    print("Need buy one bread")
else:
    print("Don't buy the bread")

