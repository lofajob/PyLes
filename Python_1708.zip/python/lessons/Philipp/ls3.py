#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Home
#
# Created:     25.04.2014
# Copyright:   (c) Home 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import math
print("Hello world")
x=input("Enter first catet ")
y=input("Enter second catet ")
c=math.sqrt(pow(x,2)+pow(y,2))
print(int(c))