#example of 'for' loop
myList = [10, 'test string', 1234, "Longer Sentece String.", -21]

for value in myList:
    print value

#second example
name = raw_input("What is your name? ")

print "Hello"

for letter in name:
    print letter

print "!"
