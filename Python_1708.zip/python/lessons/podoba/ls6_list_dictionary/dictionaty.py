#initialize
book = {
    'Vitaliy Podoba': 38097625584,
    'Stepan Vidro': 320625468987,
    'Viktor Yalinkobich': 3806766678,
    'Anton Karton': 2114568798,
}
print book

#add new value
book['Andriy Babiy'] = 80678796875
print book

#change value
book['Andriy Babiy'] = 0
print book

# delete value
del book['Andriy Babiy']
print book

