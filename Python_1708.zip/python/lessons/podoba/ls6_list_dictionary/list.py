# initializing list
colors = ['blue', 'white', 'black', 'green', 'yellow']
print colors

#append 
colors.append('grey')
print colors

#delete
del colors[2]
print colors

#pop
colors.pop(3)
print colors
