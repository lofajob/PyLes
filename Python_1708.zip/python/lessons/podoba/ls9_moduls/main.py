#-*- coding: utf-8 -*-
import moduletest

print moduletest.years
t = moduletest.Table()
t.details()
