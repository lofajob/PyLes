print "Hello"
name=raw_input("Enter your name:")
print "glade to sse you, ",name
raw_input()
