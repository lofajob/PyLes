#-*- coding: utf-8 -*-

class Second:
    color = "red"
    form = "cyrcle"

    def changecolor(self, newcolor):
        self.color = newcolor

    def changeform(self, newform):
        self.form = newform
    
